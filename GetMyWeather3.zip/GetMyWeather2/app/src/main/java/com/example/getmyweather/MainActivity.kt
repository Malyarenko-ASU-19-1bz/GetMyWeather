package com.example.getmyweather

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley

const val apikey = "8ac4344a796b4f789c7163504241301"
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val enter1 : EditText = findViewById(R.id.ent1)
        val button: Button = findViewById(R.id.bGet)
        button.setOnClickListener {
            val city = enter1.text.toString()
            val url = "https://api.weatherapi.com/v1/current.json?key=$apikey&q=$city&aqi=no"
            val queue = Volley.newRequestQueue(this)
            val stringRequest = StringRequest(Request.Method.GET,
                url,
                {
                        response->
                    Log.d("MyLog", "Response: $response")
                },
                {
                    Log.d("MyLog", "VolleyError: $it")
                }
            )
            queue.add(stringRequest)
        }
    }
}